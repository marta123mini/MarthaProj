﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Palindrome 
{
    class Program 
    {
        static void Main(string[] args) 
        {
            while (true) 
            {
                //Asking for user input
                Console.WriteLine("Please write a paragraph to test for Palindromes, please ensure that you use periods for sentences.");
                var word = Console.ReadLine();
                var isNotEmpty = !string.IsNullOrWhiteSpace(word);
                //if user input is not empty
                if (isNotEmpty) 
                {
                    //Splitting up user input by words into an array
                    var words = word.Split(" ");
                    //Calling method to obtain number of palindrome words
                    var numOfWords = wordCount(words);
                    Console.WriteLine("Number of palindrome words: " + numOfWords);
                    //Splitting up user input by sentences into an array
                    var sentences = word.Split(". ");
                    //Calling method to obtain number of palindrome sentences
                    var numOfSentences = sentenceCount(sentences);
                    Console.WriteLine("Number of palindrome sentences: " + numOfSentences);
                    //Calling method to obtain a list of unique palindrome words
                    var uniqueWords = getUniqueWords(words);
                    //Formatting out extra periods
                    word = word.Replace(".","");
                    //Splitting up user input to obtain unique palindrome instances
                    var wordsForCount = word.Split(" ");
                    //Writing unique word along with instance count to console
                    foreach(var unique in uniqueWords)
                    {
                        Console.WriteLine("Unique word: " + unique + " - Instances: " + wordsForCount.Count(w => w == unique));
                    }

                    Console.WriteLine("Please input one letter for a list of words from your paragraph that contain the letter:");
                    
                    //getting user input for word instances containing the letter 
                    var letter = Console.ReadLine();
                    var letterNotNull = !string.IsNullOrWhiteSpace(letter);

                    if(letterNotNull)
                    {
                        foreach(var w in wordsForCount)
                        {
                            if(w.Contains(letter))
                            {
                                Console.WriteLine(w);
                            }
                        }
                    }

                }
                else
                {
                    Console.WriteLine("No input has been entered.");
                }
            }
        }

        //Within this method I am obtaining the count of all Palindrome words within user's input
        static int wordCount(string[] words)
        {
            List<string> palindromes = new List<string>();

            foreach(var word in words)
            {
                //getting rid of extra punctuation
                var formattedWord = word.Replace(".","");
                var stillPalindrome = true;
                int len = formattedWord.Length,
                mid = formattedWord.Length/2;
                //iterating through for loop to ensure word is palindrome
                for (int i = 0; i < mid; i++) 
                {
                    var firstChar = formattedWord[i];
                    var lastChar = formattedWord[len - 1 - i];
                    if (firstChar.CompareTo(lastChar) != 0) 
                    {
                        stillPalindrome = false;
                    }
                }

                if(stillPalindrome)
                {
                    //if palindrome, add to list
                    palindromes.Add(formattedWord);
                }
            }
            return palindromes.Count();
        }

        //Within this method I am obtaining the count of all Palindrome sentences within user input
        static int sentenceCount(string[] sentences)
        {
            List<string> palindromes = new List<string>();

            foreach(var sentence in sentences)
            {
                //getting rid of extra punctuation and white spaces
                var formattedSentence = sentence.Replace(" ","");
                formattedSentence = formattedSentence.Replace(".","");

                var stillPalindrome = true;
                int len = formattedSentence.Length,
                mid = formattedSentence.Length/2;
                //iterating through for loop to ensure sentence is palindrome
                for (int i = 0; i < mid; i++) 
                {
                    var firstChar = formattedSentence[i];
                    var lastChar = formattedSentence[len - 1 - i];
                    if (firstChar.CompareTo(lastChar) != 0) 
                    {
                        stillPalindrome = false;
                    }
                }

                if(stillPalindrome)
                {
                    //if palindrome, add to list
                    palindromes.Add(formattedSentence);
                }
            }
            return palindromes.Count();
        }

        //Within this method I am obtaining the single instances of all palindromes
        static List<string> getUniqueWords(string[] words)
        {
            List<string> palindromes = new List<string>();

            foreach(var word in words)
            {
                //getting rid of extra punctuation
                var formattedWord = word.Replace(".","");
                var stillPalindrome = true;
                int len = formattedWord.Length,
                mid = formattedWord.Length/2;
                //iterating through for loop to ensure word is a palindrome
                for (int i = 0; i < mid; i++) 
                {
                    var firstChar = formattedWord[i];
                    var lastChar = formattedWord[len - 1 - i];
                    if (firstChar.CompareTo(lastChar) != 0) 
                    {
                        stillPalindrome = false;
                    }
                }

                if(stillPalindrome)
                {
                    //don't want duplicates, check if already contains 
                    if(!palindromes.Contains(formattedWord)){
                        palindromes.Add(formattedWord);
                    }
                }
            }
            return palindromes;
        }
    }
}